import { Button } from './ui/button';
import { Card } from './ui/card';
import { ArrowRight, Star, ShoppingBag, TruckIcon, Shield, Award } from 'lucide-react';
import { getFeaturedProducts, categories } from '../lib/products';
import { useCart } from '../lib/cart-context';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface HomePageProps {
  onNavigate: (page: string, productId?: string) => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  const featuredProducts = getFeaturedProducts();
  const { addToCart } = useCart();

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-[#1e40af] to-[#1e3a8a] text-white py-20">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="inline-block bg-[#fbbf24] text-[#1e40af] px-4 py-2 rounded-full text-sm font-semibold">
                ⭐ 5.0 Rating | Trusted by Thousands
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
                Welcome to Rinkuben Khakhrawala
              </h1>
              <p className="text-xl text-blue-100">
                Largest Namkeen Store in Kadi, Gujarat. We are Selling 20+ varieties in Namkeens, Dry fruits, Pickles & Achhar everything at one place.
              </p>
              <div className="flex flex-wrap gap-4">
                <Button
                  size="lg"
                  onClick={() => onNavigate('products')}
                  className="bg-[#fbbf24] hover:bg-[#f59e0b] text-[#1e40af]"
                >
                  Shop Now
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  onClick={() => onNavigate('franchise')}
                  className="border-white text-white hover:bg-white hover:text-[#1e40af]"
                >
                  Franchise Opportunity
                </Button>
              </div>
              <div className="flex flex-wrap gap-6 pt-4">
                <div className="flex items-center gap-2">
                  <ShoppingBag className="h-5 w-5 text-[#fbbf24]" />
                  <span className="text-sm">20+ Varieties</span>
                </div>
                <div className="flex items-center gap-2">
                  <TruckIcon className="h-5 w-5 text-[#fbbf24]" />
                  <span className="text-sm">Fast Delivery</span>
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-[#fbbf24]" />
                  <span className="text-sm">Quality Assured</span>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-square rounded-2xl overflow-hidden shadow-2xl">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1616813769023-d0557572ddbe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBraGFraHJhJTIwc25hY2tzfGVufDF8fHx8MTc2OTY5MTExMHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Rinkuben Khakhrawala Products"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 bg-white text-[#1e40af] p-6 rounded-xl shadow-xl">
                <div className="text-3xl font-bold">20+</div>
                <div className="text-sm">Product Varieties</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Badges */}
      <section className="py-12 bg-[#fef3c7]">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3 shadow-md">
                <Award className="h-8 w-8 text-[#1e40af]" />
              </div>
              <h3 className="font-semibold text-[#1e40af]">Quality Products</h3>
              <p className="text-sm text-gray-600">100% Authentic</p>
            </div>
            <div className="text-center">
              <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3 shadow-md">
                <TruckIcon className="h-8 w-8 text-[#1e40af]" />
              </div>
              <h3 className="font-semibold text-[#1e40af]">Fast Delivery</h3>
              <p className="text-sm text-gray-600">Quick & Safe</p>
            </div>
            <div className="text-center">
              <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3 shadow-md">
                <Shield className="h-8 w-8 text-[#1e40af]" />
              </div>
              <h3 className="font-semibold text-[#1e40af]">Secure Payment</h3>
              <p className="text-sm text-gray-600">Multiple Options</p>
            </div>
            <div className="text-center">
              <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3 shadow-md">
                <Star className="h-8 w-8 text-[#1e40af]" />
              </div>
              <h3 className="font-semibold text-[#1e40af]">5.0 Rating</h3>
              <p className="text-sm text-gray-600">Customer Trusted</p>
            </div>
          </div>
        </div>
      </section>

      {/* Product Categories */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-[#1e40af] mb-4">
              Shop by Category
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Explore our wide range of authentic Indian snacks, dry fruits, and pickles
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
            {categories.map((category) => (
              <Card
                key={category.id}
                className="group cursor-pointer hover:shadow-xl transition border-2 hover:border-[#fbbf24]"
                onClick={() => onNavigate('products', category.id)}
              >
                <div className="p-6 text-center">
                  <div className="text-5xl mb-4 group-hover:scale-110 transition">
                    {category.icon}
                  </div>
                  <h3 className="font-semibold text-[#1e40af] group-hover:text-[#1e3a8a]">
                    {category.name}
                  </h3>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-[#1e40af] mb-4">
              Featured Products
            </h2>
            <p className="text-gray-600">
              Handpicked bestsellers loved by our customers
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map((product) => (
              <Card key={product.id} className="group hover:shadow-xl transition overflow-hidden">
                <div className="relative aspect-square overflow-hidden bg-gray-100">
                  <ImageWithFallback
                    src={`https://images.unsplash.com/photo-1616813769023-d0557572ddbe?w=400&h=400&fit=crop`}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition"
                  />
                  <div className="absolute top-2 right-2 bg-[#fbbf24] text-[#1e40af] px-3 py-1 rounded-full text-sm font-semibold">
                    ⭐ {product.rating}
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-semibold text-[#1e40af] mb-1">{product.name}</h3>
                  <p className="text-sm text-gray-600 mb-2">{product.weight}</p>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xl font-bold text-[#1e40af]">₹{product.price}</span>
                    <span className="text-xs text-gray-500">{product.reviews} reviews</span>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      onClick={() => addToCart(product)}
                      className="flex-1 bg-[#fbbf24] hover:bg-[#f59e0b] text-[#1e40af]"
                    >
                      Add to Cart
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => onNavigate('product', product.id)}
                      className="border-[#1e40af] text-[#1e40af] hover:bg-[#1e40af] hover:text-white"
                    >
                      View
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
          <div className="text-center mt-8">
            <Button
              size="lg"
              onClick={() => onNavigate('products')}
              className="bg-[#1e40af] hover:bg-[#1e3a8a] text-white"
            >
              View All Products
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-[#1e40af] mb-4">
              What Our Customers Say
            </h2>
            <p className="text-gray-600">
              Trusted by thousands of happy customers
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                name: 'Priya Patel',
                text: 'Best khakhra in town! The quality is always consistent and the taste is authentic. I order regularly for my family.',
                rating: 5,
              },
              {
                name: 'Rajesh Shah',
                text: 'Amazing variety of products! The dry fruits are fresh and the pickles are just like homemade. Highly recommend!',
                rating: 5,
              },
              {
                name: 'Meena Desai',
                text: 'Great service and quick delivery. The ghee roasted khakhra is my absolute favorite. Will order again!',
                rating: 5,
              },
            ].map((testimonial, index) => (
              <Card key={index} className="p-6 hover:shadow-lg transition">
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-[#fbbf24] text-[#fbbf24]" />
                  ))}
                </div>
                <p className="text-gray-700 mb-4 italic">"{testimonial.text}"</p>
                <p className="font-semibold text-[#1e40af]">- {testimonial.name}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-[#1e40af] to-[#1e3a8a] text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Interested in Franchise Opportunity?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Join the Rinkuben Khakhrawala family and be part of Gujarat's fastest-growing namkeen brand
          </p>
          <Button
            size="lg"
            onClick={() => onNavigate('franchise')}
            className="bg-[#fbbf24] hover:bg-[#f59e0b] text-[#1e40af]"
          >
            Learn More About Franchise
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>
    </div>
  );
}
