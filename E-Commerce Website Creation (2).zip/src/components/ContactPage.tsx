import { useState } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { MapPin, Phone, Mail, Clock, MessageCircle, Send } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface ContactPageProps {
  onNavigate: (page: string) => void;
}

export function ContactPage({ onNavigate }: ContactPageProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('Thank you for contacting us! We will get back to you soon.');
    setFormData({
      name: '',
      email: '',
      phone: '',
      subject: '',
      message: '',
    });
  };

  const contactInfo = [
    {
      icon: <MapPin className="h-6 w-6" />,
      title: 'Visit Us',
      details: ['Hanumant Plaza, A-14', 'near Vadvala Hanumanji Mandir', 'Balapir, Kadi, Gujarat 384440'],
    },
    {
      icon: <Phone className="h-6 w-6" />,
      title: 'Call Us',
      details: ['096386 67474', 'Mon-Sun: 9 AM - 9 PM'],
    },
    {
      icon: <Mail className="h-6 w-6" />,
      title: 'Email Us',
      details: ['info@rinkubenkhakhrawala.com', 'support@rinkubenkhakhrawala.com'],
    },
    {
      icon: <Clock className="h-6 w-6" />,
      title: 'Business Hours',
      details: ['Monday - Sunday', '9:00 AM - 9:00 PM', 'Open all days'],
    },
  ];

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16 max-w-3xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-bold text-[#1e40af] mb-6">
            Get in Touch
          </h1>
          <p className="text-xl text-gray-600 leading-relaxed">
            Have questions or need assistance? We're here to help! Reach out to us through 
            any of the channels below.
          </p>
        </div>

        {/* Contact Info Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {contactInfo.map((info, index) => (
            <Card key={index} className="p-6 text-center hover:shadow-xl transition">
              <div className="text-[#fbbf24] flex justify-center mb-4">{info.icon}</div>
              <h3 className="font-semibold text-[#1e40af] mb-3">{info.title}</h3>
              <div className="text-sm text-gray-600 space-y-1">
                {info.details.map((detail, i) => (
                  <p key={i}>{detail}</p>
                ))}
              </div>
            </Card>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div>
            <Card className="p-8 shadow-xl">
              <div className="flex items-center gap-2 mb-6">
                <MessageCircle className="h-6 w-6 text-[#1e40af]" />
                <h2 className="text-2xl font-bold text-[#1e40af]">Send Us a Message</h2>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <Label htmlFor="contact-name">Full Name *</Label>
                  <Input
                    id="contact-name"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Enter your full name"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="contact-email">Email Address *</Label>
                    <Input
                      id="contact-email"
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="your.email@example.com"
                    />
                  </div>

                  <div>
                    <Label htmlFor="contact-phone">Phone Number *</Label>
                    <Input
                      id="contact-phone"
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="Your phone number"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="contact-subject">Subject *</Label>
                  <Input
                    id="contact-subject"
                    required
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    placeholder="What is your inquiry about?"
                  />
                </div>

                <div>
                  <Label htmlFor="contact-message">Message *</Label>
                  <Textarea
                    id="contact-message"
                    rows={6}
                    required
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Tell us more about your inquiry..."
                  />
                </div>

                <Button
                  type="submit"
                  size="lg"
                  className="w-full bg-[#fbbf24] hover:bg-[#f59e0b] text-[#1e40af]"
                >
                  Send Message
                  <Send className="ml-2 h-5 w-5" />
                </Button>
              </form>
            </Card>
          </div>

          {/* Map and Additional Info */}
          <div className="space-y-6">
            {/* Google Map */}
            <Card className="overflow-hidden">
              <div className="aspect-video bg-gray-200">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3664.8914936924826!2d72.33260931496866!3d23.297950784785246!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjPCsDE3JzUyLjYiTiA3MsKwMjAnMDQuMCJF!5e0!3m2!1sen!2sin!4v1234567890123"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Rinkuben Khakhrawala Location"
                ></iframe>
              </div>
              <div className="p-4 bg-[#1e40af] text-white">
                <p className="font-semibold mb-1">Hanumant Plaza, A-14</p>
                <p className="text-sm text-blue-100">near Vadvala Hanumanji Mandir, Balapir, Kadi, Gujarat</p>
              </div>
            </Card>

            {/* Quick Contact */}
            <Card className="p-6 bg-gradient-to-br from-[#1e40af] to-[#1e3a8a] text-white">
              <h3 className="text-xl font-bold mb-4">Quick Contact</h3>
              <div className="space-y-4">
                <a
                  href="tel:09638667474"
                  className="flex items-center gap-3 p-4 bg-white/10 rounded-lg hover:bg-white/20 transition"
                >
                  <Phone className="h-5 w-5 text-[#fbbf24]" />
                  <div>
                    <p className="text-sm text-blue-100">Call Now</p>
                    <p className="font-semibold">096386 67474</p>
                  </div>
                </a>

                <a
                  href="https://wa.me/919638667474"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 p-4 bg-white/10 rounded-lg hover:bg-white/20 transition"
                >
                  <MessageCircle className="h-5 w-5 text-[#fbbf24]" />
                  <div>
                    <p className="text-sm text-blue-100">WhatsApp</p>
                    <p className="font-semibold">Chat with us</p>
                  </div>
                </a>

                <a
                  href="mailto:info@rinkubenkhakhrawala.com"
                  className="flex items-center gap-3 p-4 bg-white/10 rounded-lg hover:bg-white/20 transition"
                >
                  <Mail className="h-5 w-5 text-[#fbbf24]" />
                  <div>
                    <p className="text-sm text-blue-100">Email Us</p>
                    <p className="font-semibold">info@rinkubenkhakhrawala.com</p>
                  </div>
                </a>
              </div>
            </Card>

            {/* FAQ Quick Links */}
            <Card className="p-6">
              <h3 className="text-lg font-bold text-[#1e40af] mb-4">Frequently Asked</h3>
              <div className="space-y-3 text-sm">
                <div>
                  <p className="font-semibold text-[#1e40af]">Do you deliver?</p>
                  <p className="text-gray-600">Yes, we offer delivery across Gujarat.</p>
                </div>
                <div>
                  <p className="font-semibold text-[#1e40af]">Can I order in bulk?</p>
                  <p className="text-gray-600">Absolutely! Contact us for bulk orders and special pricing.</p>
                </div>
                <div>
                  <p className="font-semibold text-[#1e40af]">Do you have a physical store?</p>
                  <p className="text-gray-600">Yes, visit us at our Kadi location during business hours.</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
