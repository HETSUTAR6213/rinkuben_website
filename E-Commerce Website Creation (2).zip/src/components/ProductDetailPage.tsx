import { useState } from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Star, ShoppingCart, Heart, Share2, Package, TruckIcon, Shield, ArrowLeft } from 'lucide-react';
import { getProductById, getProductsByCategory } from '../lib/products';
import { useCart } from '../lib/cart-context';
import { Card } from './ui/card';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { toast } from 'sonner@2.0.3';

interface ProductDetailPageProps {
  productId: string;
  onNavigate: (page: string, productId?: string) => void;
}

export function ProductDetailPage({ productId, onNavigate }: ProductDetailPageProps) {
  const product = getProductById(productId);
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-[#1e40af] mb-4">Product Not Found</h2>
          <Button onClick={() => onNavigate('products')}>
            Back to Products
          </Button>
        </div>
      </div>
    );
  }

  const relatedProducts = getProductsByCategory(product.category)
    .filter((p) => p.id !== product.id)
    .slice(0, 4);

  const handleAddToCart = () => {
    addToCart(product, quantity);
    toast.success(`Added ${quantity} ${product.name} to cart!`);
  };

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Breadcrumb */}
        <div className="mb-6">
          <Button
            variant="ghost"
            onClick={() => onNavigate('products')}
            className="text-[#1e40af] hover:text-[#1e3a8a]"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Products
          </Button>
        </div>

        {/* Product Detail */}
        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          {/* Product Images */}
          <div>
            <div className="aspect-square rounded-xl overflow-hidden bg-gray-100 mb-4">
              <ImageWithFallback
                src={`https://images.unsplash.com/photo-1616813769023-d0557572ddbe?w=800&h=800&fit=crop`}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="grid grid-cols-4 gap-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="aspect-square rounded-lg overflow-hidden bg-gray-100 cursor-pointer hover:ring-2 ring-[#fbbf24] transition">
                  <ImageWithFallback
                    src={`https://images.unsplash.com/photo-1616813769023-d0557572ddbe?w=200&h=200&fit=crop`}
                    alt={`${product.name} view ${i}`}
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Product Info */}
          <div>
            <div className="flex gap-2 mb-4">
              {product.featured && (
                <Badge className="bg-[#fbbf24] text-[#1e40af]">Featured</Badge>
              )}
              <Badge variant="outline" className="border-[#1e40af] text-[#1e40af]">
                {product.inStock ? 'In Stock' : 'Out of Stock'}
              </Badge>
            </div>

            <h1 className="text-3xl md:text-4xl font-bold text-[#1e40af] mb-4">
              {product.name}
            </h1>

            <div className="flex items-center gap-4 mb-6">
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-5 w-5 ${
                      i < Math.floor(product.rating)
                        ? 'fill-[#fbbf24] text-[#fbbf24]'
                        : 'text-gray-300'
                    }`}
                  />
                ))}
              </div>
              <span className="text-lg font-semibold text-[#1e40af]">{product.rating}</span>
              <span className="text-gray-600">({product.reviews} reviews)</span>
            </div>

            <div className="mb-6">
              <span className="text-4xl font-bold text-[#1e40af]">₹{product.price}</span>
              <span className="text-gray-600 ml-2">/ {product.weight}</span>
            </div>

            <p className="text-gray-700 mb-6 leading-relaxed">
              {product.description}
            </p>

            <div className="space-y-4 mb-8">
              <div className="flex items-center gap-2 text-gray-700">
                <Package className="h-5 w-5 text-[#1e40af]" />
                <span><strong>Weight:</strong> {product.weight}</span>
              </div>
              <div className="flex items-start gap-2 text-gray-700">
                <span className="text-[#1e40af] mt-1">📝</span>
                <span><strong>Ingredients:</strong> {product.ingredients}</span>
              </div>
            </div>

            {/* Quantity and Add to Cart */}
            <div className="flex flex-wrap gap-4 mb-8">
              <div className="flex items-center border-2 border-gray-300 rounded-lg">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-4"
                >
                  -
                </Button>
                <span className="px-6 py-2 font-semibold">{quantity}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-4"
                >
                  +
                </Button>
              </div>

              <Button
                size="lg"
                onClick={handleAddToCart}
                disabled={!product.inStock}
                className="flex-1 bg-[#fbbf24] hover:bg-[#f59e0b] text-[#1e40af]"
              >
                <ShoppingCart className="h-5 w-5 mr-2" />
                Add to Cart
              </Button>

              <Button size="lg" variant="outline" className="border-[#1e40af] text-[#1e40af]">
                <Heart className="h-5 w-5" />
              </Button>

              <Button size="lg" variant="outline" className="border-[#1e40af] text-[#1e40af]">
                <Share2 className="h-5 w-5" />
              </Button>
            </div>

            {/* Trust Badges */}
            <div className="grid grid-cols-3 gap-4 p-6 bg-[#fef3c7] rounded-lg">
              <div className="text-center">
                <TruckIcon className="h-8 w-8 text-[#1e40af] mx-auto mb-2" />
                <p className="text-sm font-semibold text-[#1e40af]">Fast Delivery</p>
              </div>
              <div className="text-center">
                <Shield className="h-8 w-8 text-[#1e40af] mx-auto mb-2" />
                <p className="text-sm font-semibold text-[#1e40af]">Quality Assured</p>
              </div>
              <div className="text-center">
                <Package className="h-8 w-8 text-[#1e40af] mx-auto mb-2" />
                <p className="text-sm font-semibold text-[#1e40af]">Safe Packaging</p>
              </div>
            </div>
          </div>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold text-[#1e40af] mb-6">Related Products</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedProducts.map((relatedProduct) => (
                <Card key={relatedProduct.id} className="group hover:shadow-xl transition overflow-hidden">
                  <div className="relative aspect-square overflow-hidden bg-gray-100">
                    <ImageWithFallback
                      src={`https://images.unsplash.com/photo-1616813769023-d0557572ddbe?w=400&h=400&fit=crop`}
                      alt={relatedProduct.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition"
                    />
                    <div className="absolute top-2 right-2 bg-[#fbbf24] text-[#1e40af] px-3 py-1 rounded-full text-sm font-semibold">
                      ⭐ {relatedProduct.rating}
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold text-[#1e40af] mb-1 line-clamp-1">
                      {relatedProduct.name}
                    </h3>
                    <p className="text-sm text-gray-600 mb-2">{relatedProduct.weight}</p>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xl font-bold text-[#1e40af]">₹{relatedProduct.price}</span>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => onNavigate('product', relatedProduct.id)}
                      className="w-full border-[#1e40af] text-[#1e40af] hover:bg-[#1e40af] hover:text-white"
                    >
                      View Details
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
