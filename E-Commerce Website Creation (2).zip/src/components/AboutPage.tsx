import { Card } from './ui/card';
import { Award, Heart, Users, Target, TrendingUp, Star } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface AboutPageProps {
  onNavigate: (page: string) => void;
}

export function AboutPage({ onNavigate }: AboutPageProps) {
  const values = [
    {
      icon: <Award className="h-8 w-8" />,
      title: 'Quality First',
      description: 'We never compromise on quality. Every product meets our strict standards.',
    },
    {
      icon: <Heart className="h-8 w-8" />,
      title: 'Customer Satisfaction',
      description: 'Your happiness is our priority. We go the extra mile for every customer.',
    },
    {
      icon: <Users className="h-8 w-8" />,
      title: 'Family Values',
      description: 'We treat every customer as part of our extended family.',
    },
    {
      icon: <Target className="h-8 w-8" />,
      title: 'Authenticity',
      description: 'Traditional recipes and authentic flavors in every product.',
    },
  ];

  const milestones = [
    {
      year: '2010',
      title: 'The Beginning',
      description: 'Started with a small shop in Kadi, offering traditional khakhra varieties.',
    },
    {
      year: '2015',
      title: 'Expansion',
      description: 'Expanded product range to include 20+ varieties of namkeens and snacks.',
    },
    {
      year: '2020',
      title: 'Recognition',
      description: 'Became the largest namkeen store in Kadi with a 5.0 customer rating.',
    },
    {
      year: '2026',
      title: 'Going Digital',
      description: 'Launched online platform to serve customers across Gujarat and beyond.',
    },
  ];

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Hero Section */}
        <div className="text-center mb-16 max-w-4xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-bold text-[#1e40af] mb-6">
            About Rinkuben Khakhrawala
          </h1>
          <p className="text-xl text-gray-600 leading-relaxed">
            A legacy of authentic flavors, quality products, and customer satisfaction. 
            Serving Kadi and beyond with traditional Indian snacks since 2010.
          </p>
        </div>

        {/* Story Section */}
        <div className="grid lg:grid-cols-2 gap-12 mb-16 items-center">
          <div>
            <h2 className="text-3xl font-bold text-[#1e40af] mb-6">Our Story</h2>
            <div className="space-y-4 text-gray-700 leading-relaxed">
              <p>
                Rinkuben Khakhrawala was born from a passion for authentic Gujarati flavors and a 
                commitment to quality. What started as a small shop in Kadi has grown into the 
                region's largest and most trusted namkeen store.
              </p>
              <p>
                Founded by Rinkuben with a vision to bring traditional, home-style snacks to every 
                household, we have maintained the same dedication to quality and authenticity that 
                defined our first day. Every product we offer is crafted with care, using traditional 
                recipes passed down through generations.
              </p>
              <p>
                Today, we are proud to serve thousands of satisfied customers with over 20 varieties 
                of khakhra, namkeen, dry fruits, and pickles. Our 5.0 rating reflects our commitment 
                to excellence and customer satisfaction.
              </p>
            </div>
          </div>
          <div className="relative">
            <div className="aspect-square rounded-2xl overflow-hidden shadow-xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1760786933663-327c858d5434?w=800&h=800&fit=crop"
                alt="Rinkuben Khakhrawala Store"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -right-6 bg-[#fbbf24] text-[#1e40af] p-6 rounded-xl shadow-xl">
              <div className="flex items-center gap-2 mb-2">
                <Star className="h-6 w-6 fill-current" />
                <span className="text-3xl font-bold">5.0</span>
              </div>
              <div className="text-sm font-semibold">Customer Rating</div>
            </div>
          </div>
        </div>

        {/* Values Section */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-[#1e40af] text-center mb-12">Our Values</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => (
              <Card key={index} className="p-6 text-center hover:shadow-xl transition">
                <div className="text-[#fbbf24] flex justify-center mb-4">{value.icon}</div>
                <h3 className="font-semibold text-[#1e40af] mb-2">{value.title}</h3>
                <p className="text-gray-600 text-sm">{value.description}</p>
              </Card>
            ))}
          </div>
        </div>

        {/* Milestones */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-[#1e40af] text-center mb-12">Our Journey</h2>
          <div className="max-w-4xl mx-auto">
            <div className="relative">
              {/* Timeline Line */}
              <div className="hidden md:block absolute left-1/2 transform -translate-x-1/2 h-full w-0.5 bg-[#fbbf24]"></div>

              {milestones.map((milestone, index) => (
                <div key={index} className={`mb-12 flex items-center ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'}`}>
                  <div className={`flex-1 ${index % 2 === 0 ? 'md:text-right md:pr-8' : 'md:text-left md:pl-8'}`}>
                    <Card className="p-6 hover:shadow-xl transition">
                      <div className="inline-block bg-[#fbbf24] text-[#1e40af] px-4 py-1 rounded-full font-bold mb-3">
                        {milestone.year}
                      </div>
                      <h3 className="text-xl font-semibold text-[#1e40af] mb-2">{milestone.title}</h3>
                      <p className="text-gray-600">{milestone.description}</p>
                    </Card>
                  </div>
                  <div className="hidden md:flex w-12 h-12 bg-[#1e40af] rounded-full items-center justify-center relative z-10 flex-shrink-0">
                    <div className="w-6 h-6 bg-[#fbbf24] rounded-full"></div>
                  </div>
                  <div className="flex-1"></div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Stats Section */}
        <div className="bg-gradient-to-r from-[#1e40af] to-[#1e3a8a] text-white rounded-2xl p-8 md:p-12 mb-16">
          <h2 className="text-3xl font-bold text-center mb-12">Our Achievements</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl md:text-5xl font-bold text-[#fbbf24] mb-2">16+</div>
              <div className="text-blue-100">Years in Business</div>
            </div>
            <div>
              <div className="text-4xl md:text-5xl font-bold text-[#fbbf24] mb-2">20+</div>
              <div className="text-blue-100">Product Varieties</div>
            </div>
            <div>
              <div className="text-4xl md:text-5xl font-bold text-[#fbbf24] mb-2">10k+</div>
              <div className="text-blue-100">Happy Customers</div>
            </div>
            <div>
              <div className="text-4xl md:text-5xl font-bold text-[#fbbf24] mb-2">5.0</div>
              <div className="text-blue-100">Customer Rating</div>
            </div>
          </div>
        </div>

        {/* Team Section */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-[#1e40af] text-center mb-6">
            Meet Our Founder
          </h2>
          <p className="text-center text-gray-600 mb-12 max-w-2xl mx-auto">
            The heart and soul behind Rinkuben Khakhrawala
          </p>
          <div className="max-w-2xl mx-auto">
            <Card className="p-8 text-center">
              <div className="w-32 h-32 bg-gradient-to-br from-[#fbbf24] to-[#f59e0b] rounded-full mx-auto mb-6 flex items-center justify-center text-5xl">
                👩‍🍳
              </div>
              <h3 className="text-2xl font-bold text-[#1e40af] mb-2">Rinkuben Khakhrawala</h3>
              <p className="text-gray-600 mb-4">Founder & Chief Quality Officer</p>
              <p className="text-gray-700 leading-relaxed">
                "My vision has always been simple - to bring the authentic taste of traditional 
                Gujarati snacks to every home. Every product we make carries the love and care 
                of home-cooked food. Quality is not just our policy; it's our promise."
              </p>
            </Card>
          </div>
        </div>

        {/* Quality Promise */}
        <div className="bg-[#fef3c7] rounded-2xl p-8 md:p-12 text-center">
          <Award className="h-16 w-16 text-[#1e40af] mx-auto mb-6" />
          <h2 className="text-3xl font-bold text-[#1e40af] mb-4">Our Quality Promise</h2>
          <p className="text-gray-700 leading-relaxed max-w-3xl mx-auto mb-6">
            We are committed to maintaining the highest standards of quality in every product we sell. 
            From sourcing the finest ingredients to maintaining strict hygiene standards, we ensure 
            that every bite delivers the authentic taste you expect and deserve.
          </p>
          <div className="flex flex-wrap justify-center gap-6 text-sm font-semibold text-[#1e40af]">
            <span>✓ 100% Authentic Ingredients</span>
            <span>✓ No Artificial Colors</span>
            <span>✓ Hygienically Prepared</span>
            <span>✓ Fresh Products</span>
          </div>
        </div>
      </div>
    </div>
  );
}
