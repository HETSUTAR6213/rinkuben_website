import { useState } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import {
  TrendingUp,
  Users,
  Award,
  Target,
  Handshake,
  BookOpen,
  HeadphonesIcon,
  CheckCircle2,
  IndianRupee,
  Store,
  GraduationCap,
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface FranchisePageProps {
  onNavigate: (page: string) => void;
}

export function FranchisePage({ onNavigate }: FranchisePageProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    city: '',
    investment: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('Thank you for your interest! Our franchise team will contact you soon.');
    setFormData({
      name: '',
      email: '',
      phone: '',
      city: '',
      investment: '',
      message: '',
    });
  };

  const benefits = [
    {
      icon: <Award className="h-8 w-8" />,
      title: 'Established Brand',
      description: 'Leverage the trust and reputation of Rinkuben Khakhrawala, the largest namkeen store in Kadi.',
    },
    {
      icon: <BookOpen className="h-8 w-8" />,
      title: 'Complete Training',
      description: 'Comprehensive training program covering operations, quality control, and customer service.',
    },
    {
      icon: <HeadphonesIcon className="h-8 w-8" />,
      title: 'Ongoing Support',
      description: '24/7 operational support and guidance from our experienced team.',
    },
    {
      icon: <TrendingUp className="h-8 w-8" />,
      title: 'Proven Business Model',
      description: 'Time-tested business model with excellent ROI and growth potential.',
    },
    {
      icon: <Store className="h-8 w-8" />,
      title: 'Marketing Support',
      description: 'Comprehensive marketing and promotional materials to drive customer footfall.',
    },
    {
      icon: <Users className="h-8 w-8" />,
      title: 'Exclusive Territory',
      description: 'Protected territory rights ensuring no competition within your area.',
    },
  ];

  const requirements = [
    {
      icon: <IndianRupee className="h-6 w-6" />,
      title: 'Investment Range',
      value: '₹10-15 Lakhs',
    },
    {
      icon: <Store className="h-6 w-6" />,
      title: 'Space Required',
      value: '400-600 sq ft',
    },
    {
      icon: <Users className="h-6 w-6" />,
      title: 'Staff Required',
      value: '2-3 People',
    },
    {
      icon: <Target className="h-6 w-6" />,
      title: 'ROI Period',
      value: '18-24 Months',
    },
  ];

  const process = [
    'Submit your franchise inquiry form',
    'Initial screening and background verification',
    'Meeting with franchise team and site evaluation',
    'Finalize terms and sign franchise agreement',
    'Store setup and staff training',
    'Grand opening with full support',
  ];

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        {/* Hero Section */}
        <div className="text-center mb-16 max-w-4xl mx-auto">
          <div className="inline-block bg-[#fef3c7] text-[#1e40af] px-6 py-2 rounded-full mb-6">
            <Handshake className="inline-block h-5 w-5 mr-2" />
            Franchise Opportunity
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-[#1e40af] mb-6">
            Partner with Gujarat's Fastest Growing Namkeen Brand
          </h1>
          <p className="text-xl text-gray-600 leading-relaxed">
            Join the Rinkuben Khakhrawala family and be part of a successful business with a proven track record. 
            Build your own profitable enterprise with our comprehensive franchise support.
          </p>
        </div>

        {/* Why Choose Us */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-[#1e40af] text-center mb-12">
            Why Choose Rinkuben Khakhrawala Franchise?
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {benefits.map((benefit, index) => (
              <Card key={index} className="p-6 hover:shadow-xl transition">
                <div className="text-[#fbbf24] mb-4">{benefit.icon}</div>
                <h3 className="text-lg font-semibold text-[#1e40af] mb-2">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </Card>
            ))}
          </div>
        </div>

        {/* Investment Details */}
        <div className="mb-16 bg-gradient-to-r from-[#1e40af] to-[#1e3a8a] text-white rounded-2xl p-8 md:p-12">
          <h2 className="text-3xl font-bold mb-8 text-center">Investment Requirements</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {requirements.map((req, index) => (
              <Card key={index} className="p-6 text-center bg-white/10 backdrop-blur border-white/20 text-white">
                <div className="text-[#fbbf24] flex justify-center mb-4">{req.icon}</div>
                <h3 className="font-semibold mb-2">{req.title}</h3>
                <p className="text-xl font-bold text-[#fbbf24]">{req.value}</p>
              </Card>
            ))}
          </div>
        </div>

        {/* Success Stories */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-[#1e40af] text-center mb-12">Success Stories</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                name: 'Amit Patel',
                location: 'Ahmedabad',
                quote: 'Partnering with Rinkuben Khakhrawala was the best business decision I made. The support and training are exceptional!',
                revenue: '₹8L+ Monthly',
              },
              {
                name: 'Priya Shah',
                location: 'Mehsana',
                quote: 'The franchise model is well-structured and profitable. I recovered my investment within 20 months.',
                revenue: '₹6L+ Monthly',
              },
              {
                name: 'Rajesh Modi',
                location: 'Gandhinagar',
                quote: 'Quality products, strong brand, and excellent support system. Highly recommended for aspiring entrepreneurs.',
                revenue: '₹7L+ Monthly',
              },
            ].map((story, index) => (
              <Card key={index} className="p-6 hover:shadow-xl transition">
                <div className="mb-4">
                  <div className="flex gap-1 mb-2">
                    {[...Array(5)].map((_, i) => (
                      <span key={i} className="text-[#fbbf24]">⭐</span>
                    ))}
                  </div>
                  <p className="text-gray-700 italic mb-4">"{story.quote}"</p>
                </div>
                <div className="border-t pt-4">
                  <p className="font-semibold text-[#1e40af]">{story.name}</p>
                  <p className="text-sm text-gray-600">{story.location}</p>
                  <p className="text-sm font-semibold text-[#fbbf24] mt-2">{story.revenue}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Process */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-[#1e40af] text-center mb-12">
            Franchise Application Process
          </h2>
          <div className="max-w-3xl mx-auto">
            {process.map((step, index) => (
              <div key={index} className="flex gap-4 mb-6">
                <div className="flex-shrink-0 w-10 h-10 bg-[#fbbf24] text-[#1e40af] rounded-full flex items-center justify-center font-bold">
                  {index + 1}
                </div>
                <div className="flex-1">
                  <p className="text-lg text-gray-700">{step}</p>
                </div>
                {index < process.length - 1 && (
                  <div className="w-0.5 bg-gray-300 ml-5 mb-2"></div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Inquiry Form */}
        <div className="max-w-3xl mx-auto">
          <Card className="p-8 shadow-xl">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-[#1e40af] mb-4">Start Your Journey Today</h2>
              <p className="text-gray-600">Fill out the form below and our franchise team will get back to you within 24 hours</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="name">Full Name *</Label>
                  <Input
                    id="name"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Enter your full name"
                  />
                </div>

                <div>
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input
                    id="phone"
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="Enter your phone number"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="email">Email Address *</Label>
                  <Input
                    id="email"
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="your.email@example.com"
                  />
                </div>

                <div>
                  <Label htmlFor="city">Preferred City *</Label>
                  <Input
                    id="city"
                    required
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    placeholder="City for franchise location"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="investment">Investment Capacity *</Label>
                <Input
                  id="investment"
                  required
                  value={formData.investment}
                  onChange={(e) => setFormData({ ...formData, investment: e.target.value })}
                  placeholder="e.g., ₹10-15 Lakhs"
                />
              </div>

              <div>
                <Label htmlFor="message">Additional Information</Label>
                <Textarea
                  id="message"
                  rows={4}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Tell us about your background and why you're interested in our franchise..."
                />
              </div>

              <Button
                type="submit"
                size="lg"
                className="w-full bg-[#fbbf24] hover:bg-[#f59e0b] text-[#1e40af]"
              >
                Submit Franchise Inquiry
                <CheckCircle2 className="ml-2 h-5 w-5" />
              </Button>
            </form>
          </Card>
        </div>

        {/* FAQ Section */}
        <div className="mt-16 max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-[#1e40af] text-center mb-12">
            Frequently Asked Questions
          </h2>
          <div className="space-y-4">
            {[
              {
                q: 'What is the total investment required?',
                a: 'The total investment ranges from ₹10-15 Lakhs, including franchise fee, setup costs, initial inventory, and working capital.',
              },
              {
                q: 'How long does it take to break even?',
                a: 'Based on our franchisee performance, most locations achieve break-even within 18-24 months with proper operations.',
              },
              {
                q: 'Do you provide training?',
                a: 'Yes, we provide comprehensive training covering all aspects of running the franchise, including operations, quality control, and customer service.',
              },
              {
                q: 'What ongoing support do you provide?',
                a: 'We provide continuous operational support, marketing materials, supply chain management, and regular business reviews.',
              },
            ].map((faq, index) => (
              <Card key={index} className="p-6">
                <h3 className="font-semibold text-[#1e40af] mb-2">{faq.q}</h3>
                <p className="text-gray-600">{faq.a}</p>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
