import { Facebook, Phone, Mail, MapPin, Clock } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: string) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="bg-[#1e40af] text-white mt-auto">
      {/* Main Footer */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-[#fbbf24] rounded-full flex items-center justify-center text-xl">
                🥙
              </div>
              <h3 className="font-bold text-lg">Rinkuben Khakhrawala</h3>
            </div>
            <p className="text-sm text-blue-100 mb-4">
              Largest Namkeen Store in Kadi, Gujarat. We are Selling 20+ varieties in Namkeens, Dry fruits, Pickles & Achhar everything at one place.
            </p>
            <div className="flex gap-3">
              <a
                href="https://www.facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-white/10 hover:bg-[#fbbf24] p-2 rounded-full transition"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a
                href="https://wa.me/919638667474"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-white/10 hover:bg-[#fbbf24] p-2 rounded-full transition"
              >
                <Phone className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm text-blue-100">
              <li>
                <button
                  onClick={() => onNavigate('home')}
                  className="hover:text-[#fbbf24] transition"
                >
                  Home
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('products')}
                  className="hover:text-[#fbbf24] transition"
                >
                  Products
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('franchise')}
                  className="hover:text-[#fbbf24] transition"
                >
                  Franchise Opportunity
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('about')}
                  className="hover:text-[#fbbf24] transition"
                >
                  About Us
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('contact')}
                  className="hover:text-[#fbbf24] transition"
                >
                  Contact Us
                </button>
              </li>
            </ul>
          </div>

          {/* Product Categories */}
          <div>
            <h3 className="font-bold mb-4">Product Categories</h3>
            <ul className="space-y-2 text-sm text-blue-100">
              <li className="hover:text-[#fbbf24] transition cursor-pointer">Khakhra Varieties</li>
              <li className="hover:text-[#fbbf24] transition cursor-pointer">Dry Snacks</li>
              <li className="hover:text-[#fbbf24] transition cursor-pointer">Dry Fruits</li>
              <li className="hover:text-[#fbbf24] transition cursor-pointer">Pickles & Achaar</li>
              <li className="hover:text-[#fbbf24] transition cursor-pointer">Namkeen</li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="font-bold mb-4">Contact Us</h3>
            <ul className="space-y-3 text-sm text-blue-100">
              <li className="flex gap-2">
                <MapPin className="h-5 w-5 flex-shrink-0 text-[#fbbf24]" />
                <span>Hanumant Plaza, A-14, near Vadvala Hanumanji Mandir, Balapir, Kadi, Gujarat 384440</span>
              </li>
              <li className="flex gap-2 items-center">
                <Phone className="h-5 w-5 flex-shrink-0 text-[#fbbf24]" />
                <a href="tel:09638667474" className="hover:text-[#fbbf24] transition">
                  096386 67474
                </a>
              </li>
              <li className="flex gap-2 items-center">
                <Clock className="h-5 w-5 flex-shrink-0 text-[#fbbf24]" />
                <span>Open until 9 PM</span>
              </li>
              <li className="flex gap-2 items-center">
                <Mail className="h-5 w-5 flex-shrink-0 text-[#fbbf24]" />
                <a href="mailto:info@rinkubenkhakhrawala.com" className="hover:text-[#fbbf24] transition">
                  info@rinkubenkhakhrawala.com
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-blue-100">
            <p>© 2026 Rinkuben Khakhrawala. All rights reserved.</p>
            <div className="flex gap-6">
              <button className="hover:text-[#fbbf24] transition">Privacy Policy</button>
              <button className="hover:text-[#fbbf24] transition">Terms & Conditions</button>
              <button className="hover:text-[#fbbf24] transition">Shipping Policy</button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
