import { ShoppingCart, Menu, X, Phone, Search, User } from 'lucide-react';
import { useState } from 'react';
import { useCart } from '../lib/cart-context';
import { Button } from './ui/button';
import { Input } from './ui/input';

interface HeaderProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export function Header({ currentPage, onNavigate }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const { getCartCount } = useCart();

  const navigation = [
    { name: 'Home', id: 'home' },
    { name: 'Products', id: 'products' },
    { name: 'Franchise', id: 'franchise' },
    { name: 'About Us', id: 'about' },
    { name: 'Contact', id: 'contact' },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white shadow-md">
      {/* Top Bar */}
      <div className="bg-[#1e40af] text-white py-2">
        <div className="container mx-auto px-4 flex justify-between items-center text-sm">
          <div className="flex items-center gap-4">
            <a href="tel:09638667474" className="flex items-center gap-2 hover:text-[#fbbf24] transition">
              <Phone className="h-4 w-4" />
              <span className="hidden sm:inline">096386 67474</span>
            </a>
            <span className="hidden md:inline">Open until 9 PM</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="hidden sm:inline">📍 Kadi, Gujarat</span>
            <span className="text-[#fbbf24]">⭐ 5.0 Rating</span>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 group"
          >
            <div className="w-12 h-12 bg-gradient-to-br from-[#fbbf24] to-[#f59e0b] rounded-full flex items-center justify-center text-2xl">
              🥙
            </div>
            <div className="hidden sm:block">
              <h1 className="text-xl font-bold text-[#1e40af] group-hover:text-[#1e3a8a] transition">
                Rinkuben Khakhrawala
              </h1>
              <p className="text-xs text-gray-600">Largest Namkeen Store in Kadi</p>
            </div>
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-6">
            {navigation.map((item) => (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`transition hover:text-[#1e40af] ${
                  currentPage === item.id
                    ? 'text-[#1e40af] font-semibold'
                    : 'text-gray-700'
                }`}
              >
                {item.name}
              </button>
            ))}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-2 sm:gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSearchOpen(!searchOpen)}
              className="hidden sm:inline-flex"
            >
              <Search className="h-5 w-5" />
            </Button>

            <Button variant="ghost" size="icon" className="hidden sm:inline-flex">
              <User className="h-5 w-5" />
            </Button>

            <Button
              variant="ghost"
              size="icon"
              onClick={() => onNavigate('cart')}
              className="relative"
            >
              <ShoppingCart className="h-5 w-5" />
              {getCartCount() > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#fbbf24] text-[#1e40af] text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                  {getCartCount()}
                </span>
              )}
            </Button>

            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </Button>
          </div>
        </div>

        {/* Search Bar */}
        {searchOpen && (
          <div className="mt-4 animate-in slide-in-from-top">
            <Input
              type="search"
              placeholder="Search for products..."
              className="w-full"
            />
          </div>
        )}
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t bg-white animate-in slide-in-from-top">
          <nav className="container mx-auto px-4 py-4 flex flex-col gap-4">
            {navigation.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`text-left py-2 transition hover:text-[#1e40af] ${
                  currentPage === item.id
                    ? 'text-[#1e40af] font-semibold'
                    : 'text-gray-700'
                }`}
              >
                {item.name}
              </button>
            ))}
            <div className="pt-2 border-t">
              <Input
                type="search"
                placeholder="Search for products..."
                className="w-full"
              />
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
