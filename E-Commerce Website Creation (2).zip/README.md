
  # E-Commerce Website Creation

  This is a code bundle for E-Commerce Website Creation. The original project is available at https://www.figma.com/design/ED9m8cHY9ShMK8jnqPQJtC/E-Commerce-Website-Creation.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  